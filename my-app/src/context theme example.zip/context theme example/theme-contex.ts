import { createContext } from "react"

export const themes={
    dark:{
        color:'white',
        background:'black',
        padding:'5%',
        margin:'2%'
    },
    light:{
        color:'black',
        background:'yellow',
        padding:'5%',
        margin:'2%'
    }
}

const ThemeContext =createContext(themes.dark)
export default ThemeContext