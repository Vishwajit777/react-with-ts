import React, { useContext } from 'react'
import ThemeContext from './theme-contex'

export const Layout = () => {
    const theme=useContext(ThemeContext)
    return (
        <div style={theme}>
         Welcome
        </div>
    )
}
